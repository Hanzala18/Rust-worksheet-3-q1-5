fn extraction(sentence:&str) -> Vec<String>{
let mut word: Vec<String> = sentence.split_whitespace().map(|word| word.to_lowercase()).collect();// vec<string> ka mtlb alg alg toore ga
word.sort();
word.dedup();
word
}

fn main() {
    let sentence = "My name is hanzala hashmi";
    let new_word= extraction(sentence);
    println!("{} = original sentence",sentence);
    println!("{:?} = words after extraction",new_word);
}
