use std::fs::File;
use std::io::prelude::*;
use std::io::Error;
use std::path::Path;

fn read_file(path: &str) -> Result<String, Error> {
    let file = File::open(path)?;
    let mut content = String::new();
    let mut reader = std::io::BufReader::new(file);
    reader.read_to_string(&mut content)?;
    Ok(content)
}

fn main() {
    let file_path = r"D:\practiceRUST\worksheets\worksheet3\q4\q4\Hanzala.txt.txt";
    match read_file(file_path) {
        Ok(content) => println!("File content = {}", content),
        Err(e) => println!("Error: {}", e),
    }
}
