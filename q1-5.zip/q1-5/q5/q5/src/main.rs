fn parse_integer(input: &str) -> Option<i32> {
    match input.parse() {
        Ok(parsed_integer) => Some(parsed_integer),
        Err(_) => None,
    }
}

fn main() {
    let valid_number_str = "42";
    let invalid_number_str = "abc";

    match parse_integer(valid_number_str) {
        Some(number) => println!("Parsed integer: {}", number),
        None => println!("Parsing failed."),
    }

    match parse_integer(invalid_number_str) {
        Some(number) => println!("Parsed integer: {}", number),
        None => println!("Parsing failed."),
    }
}
