use std::collections::HashMap;
use std::env;
use std::fs::File;
use std::io::{BufRead, BufReader};

fn main() {
    let args: Vec<String> = env::args().collect();

    if args.len() != 2 {
        eprintln!("Usage: {} <filename>", args[0]);
        std::process::exit(1);
    }

    let filename = &args[1];

    if let Ok(file) = File::open(filename) {
        let reader = BufReader::new(file);
        let mut word_count: HashMap<String, usize> = HashMap::new();

        for line in reader.lines() {
            if let Ok(line) = line {
                for word in line.split_whitespace() {

                    let cleaned_word = word
                        .chars()
                        .filter(|c| c.is_alphabetic())
                        .collect::<String>()
                        .to_lowercase();

                    *word_count.entry(cleaned_word).or_insert(0) += 1;
                }
            }
        }

        for (word, count) in &word_count {
            println!("{}: {}", word, count);
        }
    } else {
        eprintln!("Error opening the file: {}", filename);
        std::process::exit(1);
    }
}
