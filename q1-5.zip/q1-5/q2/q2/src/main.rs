fn main() {
let input = vec![4,5,9];
let sum_of_squares :i32 = input.iter().map(|&x|x*x).sum();
    println!("Square values = {:?}",input.iter().map(|&x|x*x).collect::<Vec<_>>());
    println!("Sum of squares = {:?}",sum_of_squares);
}
